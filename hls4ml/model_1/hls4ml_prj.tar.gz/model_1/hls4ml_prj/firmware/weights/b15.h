//Numpy array shape [5]
//Min -0.034770030528
//Max 0.039204508066
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
model_default_t b15[5];
#else
model_default_t b15[5] = {0.0066701062, -0.0013498248, 0.0392045081, -0.0347700305, -0.0204427633};
#endif

#endif
