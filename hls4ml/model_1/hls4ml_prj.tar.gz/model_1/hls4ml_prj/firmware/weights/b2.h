//Numpy array shape [4]
//Min -0.052549295127
//Max 0.081240996718
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.0525492951, 0.0812409967, -0.0179007445, 0.0029658449};
#endif

#endif
