// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_H__
#define __pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 6;
  static const unsigned AddressRange = 960;
  static const unsigned AddressWidth = 10;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_ram) {
        for (unsigned i = 0; i < 24 ; i = i + 1) {
            ram[i] = "0b000000";
        }
        for (unsigned i = 24; i < 48 ; i = i + 1) {
            ram[i] = "0b000001";
        }
        for (unsigned i = 48; i < 72 ; i = i + 1) {
            ram[i] = "0b000010";
        }
        for (unsigned i = 72; i < 96 ; i = i + 1) {
            ram[i] = "0b000011";
        }
        for (unsigned i = 96; i < 120 ; i = i + 1) {
            ram[i] = "0b000100";
        }
        for (unsigned i = 120; i < 144 ; i = i + 1) {
            ram[i] = "0b000101";
        }
        for (unsigned i = 144; i < 168 ; i = i + 1) {
            ram[i] = "0b000110";
        }
        for (unsigned i = 168; i < 192 ; i = i + 1) {
            ram[i] = "0b000111";
        }
        for (unsigned i = 192; i < 216 ; i = i + 1) {
            ram[i] = "0b001000";
        }
        for (unsigned i = 216; i < 240 ; i = i + 1) {
            ram[i] = "0b001001";
        }
        for (unsigned i = 240; i < 264 ; i = i + 1) {
            ram[i] = "0b001010";
        }
        for (unsigned i = 264; i < 288 ; i = i + 1) {
            ram[i] = "0b001011";
        }
        for (unsigned i = 288; i < 312 ; i = i + 1) {
            ram[i] = "0b001100";
        }
        for (unsigned i = 312; i < 336 ; i = i + 1) {
            ram[i] = "0b001101";
        }
        for (unsigned i = 336; i < 360 ; i = i + 1) {
            ram[i] = "0b001110";
        }
        for (unsigned i = 360; i < 384 ; i = i + 1) {
            ram[i] = "0b001111";
        }
        for (unsigned i = 384; i < 408 ; i = i + 1) {
            ram[i] = "0b010000";
        }
        for (unsigned i = 408; i < 432 ; i = i + 1) {
            ram[i] = "0b010001";
        }
        for (unsigned i = 432; i < 456 ; i = i + 1) {
            ram[i] = "0b010010";
        }
        for (unsigned i = 456; i < 480 ; i = i + 1) {
            ram[i] = "0b010011";
        }
        for (unsigned i = 480; i < 504 ; i = i + 1) {
            ram[i] = "0b010100";
        }
        for (unsigned i = 504; i < 528 ; i = i + 1) {
            ram[i] = "0b010101";
        }
        for (unsigned i = 528; i < 552 ; i = i + 1) {
            ram[i] = "0b010110";
        }
        for (unsigned i = 552; i < 576 ; i = i + 1) {
            ram[i] = "0b010111";
        }
        for (unsigned i = 576; i < 600 ; i = i + 1) {
            ram[i] = "0b011000";
        }
        for (unsigned i = 600; i < 624 ; i = i + 1) {
            ram[i] = "0b011001";
        }
        for (unsigned i = 624; i < 648 ; i = i + 1) {
            ram[i] = "0b011010";
        }
        for (unsigned i = 648; i < 672 ; i = i + 1) {
            ram[i] = "0b011011";
        }
        for (unsigned i = 672; i < 696 ; i = i + 1) {
            ram[i] = "0b011100";
        }
        for (unsigned i = 696; i < 720 ; i = i + 1) {
            ram[i] = "0b011101";
        }
        for (unsigned i = 720; i < 744 ; i = i + 1) {
            ram[i] = "0b011110";
        }
        for (unsigned i = 744; i < 768 ; i = i + 1) {
            ram[i] = "0b011111";
        }
        for (unsigned i = 768; i < 792 ; i = i + 1) {
            ram[i] = "0b100000";
        }
        for (unsigned i = 792; i < 816 ; i = i + 1) {
            ram[i] = "0b100001";
        }
        for (unsigned i = 816; i < 840 ; i = i + 1) {
            ram[i] = "0b100010";
        }
        for (unsigned i = 840; i < 864 ; i = i + 1) {
            ram[i] = "0b100011";
        }
        for (unsigned i = 864; i < 888 ; i = i + 1) {
            ram[i] = "0b100100";
        }
        for (unsigned i = 888; i < 912 ; i = i + 1) {
            ram[i] = "0b100101";
        }
        for (unsigned i = 912; i < 936 ; i = i + 1) {
            ram[i] = "0b100110";
        }
        for (unsigned i = 936; i < 960 ; i = i + 1) {
            ram[i] = "0b100111";
        }


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx) {


static const unsigned DataWidth = 6;
static const unsigned AddressRange = 960;
static const unsigned AddressWidth = 10;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_ram* meminst;


SC_CTOR(pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx) {
meminst = new pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_ram("pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~pointwise_conv_2d_cl_array_array_ap_fixed_4_4_5_3_0_40u_config16_s_outidx() {
    delete meminst;
}


};//endmodule
#endif
