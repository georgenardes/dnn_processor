// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_H__
#define __dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 5;
  static const unsigned AddressRange = 1800;
  static const unsigned AddressWidth = 11;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_ram) {
        for (unsigned i = 0; i < 75 ; i = i + 1) {
            ram[i] = "0b00000";
        }
        for (unsigned i = 75; i < 150 ; i = i + 1) {
            ram[i] = "0b00001";
        }
        for (unsigned i = 150; i < 225 ; i = i + 1) {
            ram[i] = "0b00010";
        }
        for (unsigned i = 225; i < 300 ; i = i + 1) {
            ram[i] = "0b00011";
        }
        for (unsigned i = 300; i < 375 ; i = i + 1) {
            ram[i] = "0b00100";
        }
        for (unsigned i = 375; i < 450 ; i = i + 1) {
            ram[i] = "0b00101";
        }
        for (unsigned i = 450; i < 525 ; i = i + 1) {
            ram[i] = "0b00110";
        }
        for (unsigned i = 525; i < 600 ; i = i + 1) {
            ram[i] = "0b00111";
        }
        for (unsigned i = 600; i < 675 ; i = i + 1) {
            ram[i] = "0b01000";
        }
        for (unsigned i = 675; i < 750 ; i = i + 1) {
            ram[i] = "0b01001";
        }
        for (unsigned i = 750; i < 825 ; i = i + 1) {
            ram[i] = "0b01010";
        }
        for (unsigned i = 825; i < 900 ; i = i + 1) {
            ram[i] = "0b01011";
        }
        for (unsigned i = 900; i < 975 ; i = i + 1) {
            ram[i] = "0b01100";
        }
        for (unsigned i = 975; i < 1050 ; i = i + 1) {
            ram[i] = "0b01101";
        }
        for (unsigned i = 1050; i < 1125 ; i = i + 1) {
            ram[i] = "0b01110";
        }
        for (unsigned i = 1125; i < 1200 ; i = i + 1) {
            ram[i] = "0b01111";
        }
        for (unsigned i = 1200; i < 1275 ; i = i + 1) {
            ram[i] = "0b10000";
        }
        for (unsigned i = 1275; i < 1350 ; i = i + 1) {
            ram[i] = "0b10001";
        }
        for (unsigned i = 1350; i < 1425 ; i = i + 1) {
            ram[i] = "0b10010";
        }
        for (unsigned i = 1425; i < 1500 ; i = i + 1) {
            ram[i] = "0b10011";
        }
        for (unsigned i = 1500; i < 1575 ; i = i + 1) {
            ram[i] = "0b10100";
        }
        for (unsigned i = 1575; i < 1650 ; i = i + 1) {
            ram[i] = "0b10101";
        }
        for (unsigned i = 1650; i < 1725 ; i = i + 1) {
            ram[i] = "0b10110";
        }
        for (unsigned i = 1725; i < 1800 ; i = i + 1) {
            ram[i] = "0b10111";
        }


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7) {


static const unsigned DataWidth = 5;
static const unsigned AddressRange = 1800;
static const unsigned AddressWidth = 11;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_ram* meminst;


SC_CTOR(dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7) {
meminst = new dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_ram("dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~dense_resource_ap_fixed_4_4_5_3_0_ap_fixed_4_4_5_3_0_config5_mult_s_outidx7() {
    delete meminst;
}


};//endmodule
#endif
