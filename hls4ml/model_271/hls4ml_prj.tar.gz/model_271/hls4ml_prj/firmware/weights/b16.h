//Numpy array shape [40]
//Min -0.071835801005
//Max 0.087798029184
//Number of zeros 0

#ifndef B16_H_
#define B16_H_

#ifndef __SYNTHESIS__
conv2d_811_bias_t b16[40];
#else
conv2d_811_bias_t b16[40] = {-0, -0, 0, 0, 0, 0, -0, -0, -0, -0, -0, 0, -0, 0, -0, -0, -0, 0, -0, -0, 0, -0, -0, 0, -0, -0, 0, 0, 0, 0, -0, -0, -0, -0, -0, -0, -0, 0, -0, -0};
#endif

#endif
