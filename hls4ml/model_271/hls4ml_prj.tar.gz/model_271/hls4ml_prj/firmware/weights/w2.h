//Numpy array shape [3, 3, 3, 1]
//Min -0.365662038326
//Max 0.405901730061
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
depthwise_conv2d_220_weight_t w2[27];
#else
depthwise_conv2d_220_weight_t w2[27] = {-0, -0, -0, 0, -0, 0, 0, -0, 0, -0, 0, 0, 0, 0, 0, -0, -0, -0, -0, 0, -0, -0, -0, -0, -0, -0, 0};
#endif

#endif
