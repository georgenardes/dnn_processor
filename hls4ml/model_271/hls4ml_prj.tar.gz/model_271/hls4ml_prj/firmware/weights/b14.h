//Numpy array shape [5]
//Min -0.074828535318
//Max 0.064535930753
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
dense_271_bias_t b14[5];
#else
dense_271_bias_t b14[5] = {0, -0, 0, -0, 0};
#endif

#endif
