//Numpy array shape [3]
//Min -0.053299915045
//Max 0.140184268355
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
depthwise_conv2d_220_bias_t b2[3];
#else
depthwise_conv2d_220_bias_t b2[3] = {0, 0, -0};
#endif

#endif
