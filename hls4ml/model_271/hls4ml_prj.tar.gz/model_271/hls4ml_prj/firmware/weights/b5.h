//Numpy array shape [24]
//Min -0.062102183700
//Max 0.251022130251
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
conv2d_810_bias_t b5[24];
#else
conv2d_810_bias_t b5[24] = {-0, 0, 0, 0, -0, -0, -0, -0, -0, -0, 0, -0, 0, -0, -0, 0, -0, -0, 0, 0, 0, -0, -0, -0};
#endif

#endif
