//Numpy array shape [24]
//Min -0.078216910362
//Max 0.040869984776
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
depthwise_conv2d_221_bias_t b8[24];
#else
depthwise_conv2d_221_bias_t b8[24] = {-0, -0, 0, -0, -0, -0, -0, 0, -0, 0, -0, 0, -0, -0, -0, -0, 0, -0, -0, -0, -0, -0, -0, -0};
#endif

#endif
